function validate(){
  var a,b;
    var cl_ = document.getElementById('cl').value;

    

    if(cl_ == null || cl_ == undefined || cl_ == ""){

        alert("Enter your current location!");

         a = false;
    }

    var st_ = document.getElementById('st').value;
    

    if(st_ == null || st_ == undefined || st_ == ""){

        alert("Enter your status!");

        b = false;

    }
    if(a != false && b != false){

        return true;

    }
    else{
    	return false;
    }
}