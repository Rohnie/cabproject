function validate(){
	  
    

    var a,b,c,f,g,h,i;




    var pp_ = document.getElementById('pp').value;
    

    if(pp_ == null || pp_ == undefined || pp_ == ""){

        alert("Fill the pickup place!");

        b = false;

    }
    
   
    
    var dp_  = document.getElementById('dp').value;

    if(dp_ == null || dp_ == undefined || dp_ == ""){

        alert("Fill the drop place!");

        c = false;

    }
    
  if(dp_ ==  pp_){
	  alert("Pick up place is same as drop place!");
	  a=false;
  }
   
    var pas_ = document.getElementById('pas').value;
    if(pas_ == null || pas_ == undefined || pas_ == ""){

        alert("Fill the number of passengers!");

        f = false;

    }
    if(isNaN(pas_)){
    	alert("Enter a valid detail in passenger!");
    	g = false;
    }
    if(pas_ > 4){
    	alert("Passenger count should be less than 5!");
    	i = false;
    }
    
   
    var cs_ = document.getElementById('cs').value;
    if(cs_ == null || cs_ == undefined || cs_ == "" ){

        alert("Fill the class!");

        h= false;

    }
    
   
    
    

    if(a != false && b != false && c != false && f != false && g != false && h != false && i != false){

        return true;

    }
    else{
    	return false;
    }

}
