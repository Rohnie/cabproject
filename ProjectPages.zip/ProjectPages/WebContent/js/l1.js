function validate(){

    

    var x,y;
   
   
    var md = document.getElementById('mailid').value;

    if(md == null || md == undefined || md == ""){

        alert("Kindly enter mailid");

        x = false;

    }
    

    var pswd = document.getElementById('pword').value;

    if(pswd == null || pswd == undefined || pswd == ""){

        alert("Kindly enter password");

        y = false;

        if(x != false && y != false){

            return true;

        }
        else
        	return false;

    }
    }
    