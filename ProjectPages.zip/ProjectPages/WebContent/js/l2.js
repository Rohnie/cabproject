function validate(){

    

    var x,a,b,c,d,e,f,g,h,i;
  
    var md = document.getElementById('mailid').value;

    if(md == null || md == undefined || md == ""){

        alert("Kindly enter mailid");

        x = false;

    }
    
 var fn  = document.getElementById('fname').value;

    if(fn == null || fn == undefined || fn == ""){

        alert("Fill out first name");

        a = false;

    }
    if(/\d/.test(fn)){
    	alert("Enter a valid first name!");
    	 i = false;
    }
    
    var ln = document.getElementById('lname').value;

    if(/\d/.test(ln)){

        alert("Enter a valid last name!");

        b = false;

    }
    
    var mob = document.getElementById('mobnum').value;
    if(mob.length != 10){
    	alert("Enter a valid mobile number");

        h = false;
    }

    if(mob == null || mob == undefined || mob == "" ){

        alert("Fill out mobile number");

        c = false;

    }
    if(isNaN(mob)){
    	alert("Enter a valid mobile number");
    	e = false;
    }
    
    var ocp = document.getElementById('opword').value;

    if(ocp == null || ocp == undefined || ocp == ""){

        alert("Fill out the password");

        f = false;

    }
    
    var cp = document.getElementById('cpword').value;

    if(cp == null || cp == undefined || cp == ""){

        alert("Fill out the confirm password");

        d = false;

    }
    if(cp!=ocp){
    	alert("Password does not match");

        g = false;

    }
    
    
    

    if(x != false && a != false && b != false && c != false && d != false && e != false && f != false && g != false && h != false && i != false){

        return true;

    }
    else
    	return false;

}



