package FareCalculation;

public class FareDetailBean {
	private String fromplace;
    private String toplace;
   private int totaldistance;
    
	private int fare;
    private String type;
    public String getFromplace() {
		return fromplace;
	}
	public void setFromplace(String fromplace) {
		this.fromplace = fromplace;
	}
	public String getToplace() {
		return toplace;
	}
	public void setToplace(String toplace) {
		this.toplace = toplace;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public int getTotaldistance() {
		return totaldistance;
	}
	public void setTotaldistance(int totaldistance) {
		this.totaldistance = totaldistance;
	}
}
