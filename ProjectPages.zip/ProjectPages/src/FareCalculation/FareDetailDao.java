package FareCalculation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.ConnectionManager;

//import project.ConnectionManager;

public class FareDetailDao {
	public ArrayList<FareDetailBean> fareCalculation(FareDetailBean fareDetailBean) {

		// step 3: create statement object
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<FareDetailBean> fareList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHDQ_FARE_DET WHERE FROM_PLACE = ? AND TO_PLACE= ? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, fareDetailBean.getFromplace());
			stmt.setString(2, fareDetailBean.getToplace());

			resultset = stmt.executeQuery();

			fareList = new ArrayList<FareDetailBean>();

			while (resultset.next()) {
				/*
				 * FareDetailBean fareDetailBean = new FareDetailBean();
				 * fareDetailBean
				 * .setFromplace(resultset.getString("FROM_PLACE"));
				 * fareDetailBean.setToplace(resultset.getString("TO_PLACE"));
				 */
				fareDetailBean.setTotaldistance((resultset
						.getInt("TOTAL_DISTANCE")));
				if (fareDetailBean.getType().equals("economy")) {
					fareDetailBean.setFare(resultset.getInt("TOTAL_DISTANCE") * 40);
					
				} else {
					
					fareDetailBean.setFare((resultset.getInt("TOTAL_DISTANCE") * 40)+20);
					
					
				}
				fareList.add(fareDetailBean);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return (ArrayList<FareDetailBean>) fareList;
	}
}
