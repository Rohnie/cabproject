package FareCalculation;

import java.util.ArrayList;

public class FareDetail {
	public ArrayList<FareDetailBean> fareCalculation(FareDetailBean fareDetailBean) throws ClassNotFoundException{
		/*boolean result=false;*/
		FareDetailDao fareDetailDao = new FareDetailDao();
		return fareDetailDao.fareCalculation(fareDetailBean);
	}
}
