package NearbyCab;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.ConnectionManager;
import FareCalculation.FareDetailBean;
//import project.ConnectionManager;

public class NearbyCabDao {
public ArrayList<NearbyCabBean> showCab(NearbyCabBean nearbyCabBean){
		
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<NearbyCabBean> cabList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHDQ_CAB_DET WHERE CURRENT_PLACE= ? ";
		
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, nearbyCabBean.getCurrentPlace());
			

			resultset = stmt.executeQuery();

			cabList = new ArrayList<NearbyCabBean>();

			while (resultset.next()) {
				if(resultset.getString(5).equals("free")){
					NearbyCabBean cab = new NearbyCabBean();
					cab.setCabnumber(resultset.getString(1));
					cab.setCurrentPlace(resultset.getString(4));
					cabList.add(cab);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	//	System.out.println(cabList.size());
		return (ArrayList<NearbyCabBean>) cabList;
	}
}


