package NearbyCab;

import java.util.ArrayList;



public class NearbyCab {
	public ArrayList<NearbyCabBean> showCab(NearbyCabBean nearbyCabBean) throws ClassNotFoundException{
		
		NearbyCabDao nearbyCabDao = new NearbyCabDao();
		return nearbyCabDao.showCab(nearbyCabBean);
	}
}
