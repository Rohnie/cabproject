package CabCancellation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import DBConnection.ConnectionManager;

//import project.ConnectionManager;

public class CabCancelDao {
public void updateCabList(String cabNum){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		String searchQuery = "UPDATE T_XBBNHDQ_CAB_DET SET STATUS='free' WHERE CAB_NUM=?";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			 
			 stmt.setString(1, cabNum);
		     stmt.executeUpdate();	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
	}
}
