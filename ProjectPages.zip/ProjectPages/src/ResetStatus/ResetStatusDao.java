package ResetStatus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.ConnectionManager;


public class ResetStatusDao {
public void reset(String mail_id){
		
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		ResultSet resultset = null;
		String searchQuery = "UPDATE T_XBBNHDQ_MAP SET STATUS='serviced' WHERE DRIVER_ID=?";
		
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mail_id);
			stmt.executeUpdate();
			
			// update cab_det table set status = free	
			searchQuery = "SELECT MOBILE_NUMBER from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mail_id);
			resultset = stmt.executeQuery();
			while (resultset.next()) {
				String phno=resultset.getString(1);
				searchQuery = "UPDATE T_XBBNHDQ_CAB_DET SET STATUS='free' WHERE PHNO=?";
				 stmt = conn.prepareStatement(searchQuery);
				 stmt.setString(1, phno);
				 stmt.executeUpdate();	
			}
			
			// 
			 
        } catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
}
