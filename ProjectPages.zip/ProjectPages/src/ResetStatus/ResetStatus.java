package ResetStatus;

import java.util.ArrayList;


public class ResetStatus {
	public void reset(String mail_id) throws ClassNotFoundException{
		/*boolean result=false;*/
		ResetStatusDao resetStatusDao = new ResetStatusDao();
		resetStatusDao.reset(mail_id);
	}
}
