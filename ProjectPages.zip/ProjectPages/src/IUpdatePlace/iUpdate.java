package IUpdatePlace;

import CustomerDetails.CustomerDetailsBean;
import UpdateStatus.UpdatePlaceBean;

public interface iUpdate {
	public void updateCabList(UpdatePlaceBean updatePlaceBean);
	public CustomerDetailsBean checkRequest(String mail_id, UpdatePlaceBean updatePlaceBean);
	public boolean checkStatus (String mail_id);
}
