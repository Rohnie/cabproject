package Viewdetails;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import DBConnection.ConnectionManager;


public class DetailDao {
public ArrayList<DetailBean> getDetails(){
		
	
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<DetailBean> detailList = null;
		ResultSet resultset = null;
		
		String searchQuery = "SELECT * from T_XBBNHDQ_LOGIN_DET";
		try {
			 stmt = conn.prepareStatement(searchQuery);
					
			
			 resultset = stmt.executeQuery();	
			
	//		 cabDetailList = new ArrayList<CabDetailBean>();
			 detailList = new ArrayList<DetailBean>();
			while(resultset.next()) {
				DetailBean detailBean = new DetailBean();
				detailBean.setFirstName(resultset.getString(1));
				detailBean.setLastName(resultset.getString(2));
				detailBean.setEmail(resultset.getString(3));
				detailBean.setMobileNum(resultset.getString(4));
				detailBean.setPassword(resultset.getString(5));
				detailBean.setUser_type(resultset.getString(6));
				
			detailList.add(detailBean);
				 
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		return (ArrayList<DetailBean>) detailList;
	}
}
