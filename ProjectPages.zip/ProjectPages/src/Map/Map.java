package Map;

import java.util.ArrayList;

public class Map {
	public void mapDetails(MapBean mapBean) throws ClassNotFoundException{
		
		
		MapDao mapDao = new MapDao();
		mapDao.mapDetails(mapBean);
	}
}
