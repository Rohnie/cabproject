package Map;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import CabDetails.CabDetailBean;
import DBConnection.ConnectionManager;

public class MapDao {
	public void mapDetails(MapBean mapBean) {

		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<CabDetailBean> cabDetailList = null;
		ResultSet resultset = null;
	
		String searchQuery = "SELECT EMAIL_ID from T_XBBNHDQ_LOGIN_DET INNER JOIN T_XBBNHDQ_CAB_DET ON MOBILE_NUMBER=PHNO WHERE CAB_NUM= ? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mapBean.getCabNumber());
			resultset = stmt.executeQuery();
			while (resultset.next()) {
				mapBean.setDriver_id(resultset.getString(1));
				
			}

		/*String searchQuery = "SELECT PHNO from T_XBBNHDQ_CAB_DET WHERE CAB_NUM= ? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mapBean.getCabNumber());
			resultset = stmt.executeQuery();

		
			
			while (resultset.next()) {
				String phoneNumber = resultset.getString(1);
				searchQuery = "SELECT EMAIL_ID from T_XBBNHDQ_LOGIN_DET WHERE MOBILE_NUMBER= ? ";
				stmt = conn.prepareStatement(searchQuery);
				stmt.setString(1, phoneNumber);
				ResultSet resultset1 = stmt.executeQuery();
				while (resultset1.next()) {
					mapBean.setDriver_id(resultset1.getString(1));
					
				}
			}*/

			searchQuery = "SELECT MOBILE_NUMBER from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID = ? ";
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mapBean.getCustomer_id());
			ResultSet resultset1 = stmt.executeQuery();
			while (resultset1.next()) {
				
				mapBean.setMob_num(resultset1.getString(1));
			}
            
			searchQuery = "SELECT * from T_XBBNHDQ_MAP WHERE CUST_ID = ? ";
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mapBean.getCustomer_id());
			ResultSet resultset2 = stmt.executeQuery();
			 if(resultset2.next()){
				 searchQuery = "UPDATE T_XBBNHDQ_MAP SET DRIVER_ID=?, PICK_UP=?, DROP_PLACE=?, FARE=?, STATUS=? WHERE CUST_ID=?";
				 stmt = conn.prepareStatement(searchQuery);
				 
					stmt.setString(1, mapBean.getDriver_id());
					stmt.setString(2, mapBean.getPick_up());
					stmt.setString(3, mapBean.getDrop());
					stmt.setInt(4, mapBean.getFare());
					stmt.setString(5, mapBean.getStatus());
					stmt.setString(6, mapBean.getCustomer_id());
			     stmt.executeUpdate();	 
			 }
			
			 else{
			searchQuery = "INSERT INTO T_XBBNHDQ_MAP(CUST_ID, DRIVER_ID, PICK_UP , DROP_PLACE, MOB_NUM, FARE, STATUS) values(?,?,?,?,?,?,?)";
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mapBean.getCustomer_id());
			stmt.setString(2, mapBean.getDriver_id());
			stmt.setString(3, mapBean.getPick_up());
			stmt.setString(4, mapBean.getDrop());
			stmt.setString(5, mapBean.getMob_num());
			stmt.setInt(6, mapBean.getFare());
			stmt.setString(7, mapBean.getStatus());
			stmt.executeUpdate();	 
			 }
			
		//  update cab details table to busy status	
			 searchQuery = "UPDATE T_XBBNHDQ_CAB_DET SET STATUS='busy' WHERE CAB_NUM=?";
			 stmt = conn.prepareStatement(searchQuery);
			 stmt.setString(1, mapBean.getCabNumber());
			 stmt.executeUpdate();	
		//  end	 

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
	}
}
