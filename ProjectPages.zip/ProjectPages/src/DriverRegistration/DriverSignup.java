package DriverRegistration;



public class DriverSignup {
	public boolean validate(DriverSignupBean driverSignupBean) throws ClassNotFoundException{
		boolean result=false;
		DriverSignupDao driversignupdao = new DriverSignupDao();
		result=driversignupdao.validate(driverSignupBean);
		return result;
	}
}
