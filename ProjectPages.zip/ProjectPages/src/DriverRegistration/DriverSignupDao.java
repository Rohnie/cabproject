package DriverRegistration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBConnection.ConnectionManager;


public class DriverSignupDao {
	public boolean validate(DriverSignupBean driverSignupBean) throws ClassNotFoundException {
		boolean result=false;
		String password=null;
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		ResultSet resultset = null;
		String searchQuery = "SELECT PASSWORD from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, driverSignupBean.getEmail());		
			
			 resultset = stmt.executeQuery();	
			
			
			 
			if(resultset.next()) {
				
				result=false;
			    }
			
			else{
				String searchQuery1="INSERT INTO T_XBBNHDQ_LOGIN_DET(FIRST_NAME,LAST_NAME,EMAIL_ID,MOBILE_NUMBER,PASSWORD,USER_TYPE) values(?,?,?,?,?,?)";
				stmt = conn.prepareStatement(searchQuery1);
				 stmt.setString(1, driverSignupBean.getFirstName());
				 stmt.setString(2, driverSignupBean.getLastName());
				 stmt.setString(3, driverSignupBean.getEmail());
				 stmt.setString(4, driverSignupBean.getMobileNum());
				 stmt.setString(5, driverSignupBean.getPassword());
				 stmt.setString(6, driverSignupBean.getUser_type());
			     stmt.executeUpdate();	
			    
			     
			     String searchQuery2="INSERT INTO T_XBBNHDQ_CAB_DET(CAB_NUM,NAME,PHNO,CURRENT_PLACE,STATUS) values(?,?,?,?,?)";
					stmt = conn.prepareStatement(searchQuery2);
					 stmt.setString(1, driverSignupBean.getCabNum());
					 stmt.setString(2, driverSignupBean.getFirstName()+" "+driverSignupBean.getLastName());
					 stmt.setString(3, driverSignupBean.getMobileNum());
					 stmt.setString(4, driverSignupBean.getPlace());
					 stmt.setString(5, driverSignupBean.getStatus());
					
				     stmt.executeUpdate();	
				     result=true;
			}
			
			
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return result;
	}
}
