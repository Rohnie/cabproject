package Login;

public class Login {
public boolean validate(LoginBean loginbean) throws ClassNotFoundException{
	boolean result=false;
	LoginDao loginDao = new LoginDao();
	result=loginDao.validate(loginbean);
	return result;
}
public int redirect(LoginBean loginbean) throws ClassNotFoundException{
	int result=0;
	LoginDao loginDao = new LoginDao();
	result=loginDao.redirect(loginbean);
	return result;
}
}
