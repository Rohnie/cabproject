package Login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.ConnectionManager;

//import project.ConnectionManager;




public class LoginDao {
public boolean validate(LoginBean loginbean) throws ClassNotFoundException {
	boolean result=false;
	String password=null;
	
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	
	ResultSet resultset = null;
	String searchQuery = "SELECT PASSWORD from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
	try {
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, loginbean.getEmail());		
		
		 resultset = stmt.executeQuery();	
		
		
		 
		while(resultset.next()) {
			password=resultset.getString(1);
		
			if(password.equals(loginbean.getPassword())){
				result=true;
		    }
		}
		if(password==null){
			result=false;
		}
		
		
	}
	catch (SQLException e) {
		
		e.printStackTrace();
	}	
	finally{
		try {
			if(resultset != null)
			resultset.close();
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
	
	return result;
}

public int redirect(LoginBean loginbean) throws ClassNotFoundException {
	int result=0;
	
	String type=null;
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	
	ResultSet resultset = null;
	String searchQuery = "SELECT USER_TYPE from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
	try {
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, loginbean.getEmail());		
		
		 resultset = stmt.executeQuery();	
		
		
		 
		while(resultset.next()) {
			type=resultset.getString(1);
		//	type=resultset.getString(2);
			if(type.equals("customer")){
				result=1;
		    }
			else if(type.equals("driver")){
				result=2;
			}
			else{
				result=3;
			}
		}
		
		
		
	}
	catch (SQLException e) {
		
		e.printStackTrace();
	}	
	finally{
		try {
			if(resultset != null)
			resultset.close();
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
	
	return result;
}
}
