package CabDetails;

import java.util.ArrayList;



public class CabDetail{
	public ArrayList<CabDetailBean> showCabDetail(CabDetailBean cabDetailBean) throws ClassNotFoundException{
		/*boolean result=false;*/
		CabDetailDao cabDetailDao = new CabDetailDao();
		return cabDetailDao.showCabDetail(cabDetailBean);
	}
}
