package CabDetails;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.ConnectionManager;
import NearbyCab.NearbyCabBean;
//import project.ConnectionManager;

public class CabDetailDao {
public ArrayList<CabDetailBean> showCabDetail(CabDetailBean cabDetailBean){
		
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<CabDetailBean> cabDetailList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHDQ_CAB_DET WHERE CAB_NUM= ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, cabDetailBean.getCabnumber());		
			
			 resultset = stmt.executeQuery();	
			
	//		 cabDetailList = new ArrayList<CabDetailBean>();
			 
			while(resultset.next()) {
				 cabDetailList = new ArrayList<CabDetailBean>();
				
				cabDetailBean.setName(resultset.getString(2));
				cabDetailBean.setPhno(resultset.getString(3));
				cabDetailList.add(cabDetailBean);
						
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		return (ArrayList<CabDetailBean>) cabDetailList;
	}
}



