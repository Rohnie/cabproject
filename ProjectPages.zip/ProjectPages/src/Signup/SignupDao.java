package Signup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBConnection.ConnectionManager;

//import project.ConnectionManager;

public class SignupDao {
	public boolean validate(SignupBean signupbean) throws ClassNotFoundException {
		boolean result=false;
		String password=null;
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		ResultSet resultset = null;
		String searchQuery = "SELECT PASSWORD from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, signupbean.getEmail());		
			
			 resultset = stmt.executeQuery();	
			
			
			 
			if(resultset.next()) {
				
				result=false;
			    }
			
			else{
				String searchQuery1="INSERT INTO T_XBBNHDQ_LOGIN_DET(FIRST_NAME,LAST_NAME,EMAIL_ID,MOBILE_NUMBER,PASSWORD,USER_TYPE) values(?,?,?,?,?,?)";
				stmt = conn.prepareStatement(searchQuery1);
				 stmt.setString(1, signupbean.getFirstName());
				 stmt.setString(2, signupbean.getLastName());
				 stmt.setString(3, signupbean.getEmail());
				 stmt.setString(4, signupbean.getMobileNum());
				 stmt.setString(5, signupbean.getPassword());
				 stmt.setString(6, signupbean.getUser_type());
			     stmt.executeUpdate();	
			     result=true;
			}
			
			
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return result;
	}
}
