package Signup;



public class Signup {
	public boolean validate(SignupBean signupBean) throws ClassNotFoundException{
		boolean result=false;
		SignupDao signupdao = new SignupDao();
		result=signupdao.validate(signupBean);
		return result;
	}
}
