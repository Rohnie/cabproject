package CustomerDetails;

public class CustomerDetailsBean {
	private String customer_id;
	private String name;
	private String driver_id;
	private String pick_up;
	private String drop;
	private String mob_num;
	private int fare;
	private String status="requested";
	private String cabNumber;
	
	public CustomerDetailsBean(){
		this.name="";
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getCabNumber() {
		return cabNumber;
	}

	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public String getDriver_id() {
		return driver_id;
	}

	public void setDriver_id(String driver_id) {
		this.driver_id = driver_id;
	}

	public String getPick_up() {
		return pick_up;
	}

	public void setPick_up(String pick_up) {
		this.pick_up = pick_up;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(String drop) {
		this.drop = drop;
	}

	public String getMob_num() {
		return mob_num;
	}

	public void setMob_num(String mob_num) {
		this.mob_num = mob_num;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
