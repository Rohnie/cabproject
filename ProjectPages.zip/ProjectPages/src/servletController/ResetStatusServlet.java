package servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ResetStatus.ResetStatus;



public class ResetStatusServlet extends HttpServlet {
	 public void doGet(HttpServletRequest request, HttpServletResponse response)  
             throws ServletException, IOException{
		 HttpSession session = request.getSession(false);
		  if(session == null)
		    {	
		    	
		    	
		        response.sendRedirect("Login.html");
		    }else{
            try {
            	reset(request, response);
            } catch (ClassNotFoundException e) {
                   
                   e.printStackTrace();
            } 
     }
	 }

     private void reset(HttpServletRequest request,
                   HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
          
    	 ResetStatus resetStatus = new ResetStatus();
         response.setContentType("text/html");  
         PrintWriter out = response.getWriter(); 
         HttpSession session = request.getSession(false);
       
       
         String mail_id = (String)session.getAttribute("mail");
         resetStatus.reset(mail_id);
         
         RequestDispatcher requestDispatcher = request.getRequestDispatcher("Cabstatus.jsp");
         requestDispatcher.include(request, response);
     }
}
