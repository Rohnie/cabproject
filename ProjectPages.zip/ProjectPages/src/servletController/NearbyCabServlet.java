package servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import NearbyCab.NearbyCab;
import NearbyCab.NearbyCabBean;

public class NearbyCabServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		  if(session == null)
		    {	
		    	
		    	
		        response.sendRedirect("Login.html");
		    }
		  else{
		try {
			showNearbyCabs(request, response);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	}

	private void showNearbyCabs(HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			ClassNotFoundException, ServletException {

		NearbyCabBean nearbyCabBean = new NearbyCabBean();
		NearbyCab nearbyCab = new NearbyCab();
		HttpSession session = request.getSession(false);
		  
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		nearbyCabBean.setCurrentPlace(request.getParameter("pp"));
		session.setAttribute("fare", request.getParameter("fa"));
		ArrayList<NearbyCabBean> arraylist = new ArrayList<NearbyCabBean>();

		try {
			arraylist = nearbyCab.showCab(nearbyCabBean);
			request.setAttribute("arraylist", arraylist);
			RequestDispatcher rd = request
					.getRequestDispatcher("CabSelection.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
