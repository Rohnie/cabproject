package servletController;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Login.Login;
import Login.LoginBean;

public class loginValidator extends HttpServlet{
       public void doGet(HttpServletRequest request, HttpServletResponse response)  
               throws ServletException, IOException{
              try {
                     validateUser(request, response);
              } catch (ClassNotFoundException e) {
                    
                     e.printStackTrace();
              } 
       }

       private void validateUser(HttpServletRequest request,
                     HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
           
             LoginBean loginBean = new LoginBean();
              Login login = new Login();
              boolean result = false;
              
              response.setContentType("text/html");  
           PrintWriter out = response.getWriter(); 
           
           String mailid = request.getParameter("mail");
           String password = request.getParameter("pass");
           
           loginBean.setEmail(mailid);
           loginBean.setPassword(password);
            
          int redirect =  login.redirect(loginBean);
          if(redirect==1){
           result = login.validate(loginBean);
           
           if(result){
        	   HttpSession session = request.getSession(true);
        	   session.setAttribute("mail",mailid);  
        	   RequestDispatcher requestDispatcher = request.getRequestDispatcher("Drivedetails.jsp");
        	   requestDispatcher.include(request, response);
        	  
           }
           else{
              out.print("<font color='#f9b535'>Sorry UserName or Password Error!</font>");
              RequestDispatcher requestDispatcher = request.getRequestDispatcher("Login.jsp");
              requestDispatcher.include(request, response);
           }
          }
          else if(redirect==2){
        	  result = login.validate(loginBean);
              
              if(result){
           	   HttpSession session = request.getSession(true);
           	   session.setAttribute("mail",mailid);  
           	   RequestDispatcher requestDispatcher = request.getRequestDispatcher("Cabstatus.jsp");
           	   requestDispatcher.include(request, response);
           	  
              }
              else{
                 out.print("<font color='#f9b535'>Sorry UserName or Password Error!</font>");
                 RequestDispatcher requestDispatcher = request.getRequestDispatcher("Login.jsp");
                 requestDispatcher.include(request, response);
              }
          }
          else{
              result = login.validate(loginBean);
              
              if(result){
           	   HttpSession session = request.getSession(true);
           	   session.setAttribute("mail",mailid);  
           	   RequestDispatcher requestDispatcher = request.getRequestDispatcher("AdminEdit.jsp");
           	   requestDispatcher.include(request, response);
           	  
              }
              else{
                 out.print("<font color='#f9b535'>Sorry UserName or Password Error!</font>");
                 RequestDispatcher requestDispatcher = request.getRequestDispatcher("Login.jsp");
                 requestDispatcher.include(request, response);
              } 
          }
        	  
       }
}

