package servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DriverRegistration.DriverSignup;
import DriverRegistration.DriverSignupBean;



public class DriverSignupValidator extends HttpServlet {
	 public void doGet(HttpServletRequest request, HttpServletResponse response)  
             throws ServletException, IOException{
		 HttpSession session = request.getSession(false);
		 
		    	
		    
		 
            try {
                   validateUser(request, response);
            } catch (ClassNotFoundException e) {
                 
                   e.printStackTrace();
            } 
     }
	 

     private void validateUser(HttpServletRequest request,
                   HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
            
    	 
           DriverSignupBean driverSignupBean = new DriverSignupBean();
           DriverSignup driverSignup = new DriverSignup();
            boolean result = false;
            
            response.setContentType("text/html");  
         PrintWriter out = response.getWriter(); 
         
         String firstName = request.getParameter("fn");
         String lastName = request.getParameter("ln");
         String mobileNum = request.getParameter("mn");
         String mail_id = request.getParameter("mi");
         String password = request.getParameter("cp");
         
         String cabNum=request.getParameter("cn");
         driverSignupBean.setCabNum(cabNum);
         String place=request.getParameter("pl");
         driverSignupBean.setPlace(place);
         
         
         
         driverSignupBean.setEmail(mail_id);
         driverSignupBean.setFirstName(firstName);
         driverSignupBean.setLastName(lastName);
         driverSignupBean.setMobileNum(mobileNum);
         driverSignupBean.setPassword(password);
         
         result = driverSignup.validate(driverSignupBean);
        
         if(result){
        	 out.print("<font color='#f9b535'>Successfully Registered!</font>");
        	 RequestDispatcher requestDispatcher = request.getRequestDispatcher("DriverRegistration.jsp");
        	 requestDispatcher.include(request, response);
         }
         else{
            out.print("<font color='#f9b535'>Sorry mail id already exists</font>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("DriverRegistration.jsp");
            requestDispatcher.include(request, response);
         }
         
         
         
     }
}
