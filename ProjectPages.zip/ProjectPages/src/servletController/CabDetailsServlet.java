package servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import CabDetails.CabDetail;
import CabDetails.CabDetailBean;
import FareCalculation.FareDetail;
import FareCalculation.FareDetailBean;
import Map.Map;
import Map.MapBean;

public class CabDetailsServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		  if(session == null)
		    {	
		    	
		    	
		        response.sendRedirect("Login.html");
		    }
		  else{
		try {
			
			showCabDetails(request, response);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	}

	private void showCabDetails(HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			ClassNotFoundException, ServletException {

		
		CabDetailBean cabDetailBean = new CabDetailBean();
		CabDetail cabDetail = new CabDetail();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		cabDetailBean.setCabnumber(request.getParameter("cabNum")); 
		
		HttpSession session = request.getSession(false);
			  
		 session.setAttribute("cabnum",request.getParameter("cabNum")); 
		 
		 //Getting driver name and number to insert into table
		 try{
			 MapBean mapbean = new MapBean();
			 mapbean.setCustomer_id(session.getAttribute("mail").toString());
			 mapbean.setPick_up(session.getAttribute("pickup").toString());
			 mapbean.setDrop(session.getAttribute("drop").toString());
			 mapbean.setFare(Integer.parseInt((String)session.getAttribute("fare")));
			 mapbean.setCabNumber(session.getAttribute("cabnum").toString());
			 Map map = new Map();
			 map.mapDetails(mapbean);
			 
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		 
		ArrayList<CabDetailBean> arraylist = new ArrayList<CabDetailBean>();

		try {
			arraylist = cabDetail.showCabDetail(cabDetailBean);
			request.setAttribute("arraylist", arraylist);
			RequestDispatcher rd = request.getRequestDispatcher("Driverdetails.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
