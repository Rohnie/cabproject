package servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import Signup.Signup;
import Signup.SignupBean;

public class SignupValidator extends HttpServlet {
	 public void doGet(HttpServletRequest request, HttpServletResponse response)  
             throws ServletException, IOException{
		 
            try {
                   validateUser(request, response);
            } catch (ClassNotFoundException e) {
                   // TODO Auto-generated catch block
                   e.printStackTrace();
            } 
     }

     private void validateUser(HttpServletRequest request,
                   HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
            // TODO Auto-generated method stub
    	 
           SignupBean signupbean = new SignupBean();
           Signup signup = new Signup();
            boolean result = false;
            
            response.setContentType("text/html");  
         PrintWriter out = response.getWriter(); 
         
         String firstName = request.getParameter("fn");
         String lastName = request.getParameter("ln");
         String mobileNum = request.getParameter("mn");
         String mail_id = request.getParameter("mi");
         String password = request.getParameter("cp");
         
        
         
         
         signupbean.setEmail(mail_id);
         signupbean.setFirstName(firstName);
         signupbean.setLastName(lastName);
         signupbean.setMobileNum(mobileNum);
         signupbean.setPassword(password);
         
         result = signup.validate(signupbean);
        
         if(result){
        	 out.print("<font color='#f9b535'>Successfully signed up!</font>");
        	 RequestDispatcher requestDispatcher = request.getRequestDispatcher("Login.jsp");
        	 requestDispatcher.include(request, response);
         }
         else{
            out.print("<font color='#f9b535'>Sorry mail id already exists</font>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("Loginpage3.html");
            requestDispatcher.include(request, response);
         }
         
         
         
     }
}
