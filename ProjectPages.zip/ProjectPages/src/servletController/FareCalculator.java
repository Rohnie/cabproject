package servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import FareCalculation.FareDetail;
import FareCalculation.FareDetailBean;

public class FareCalculator extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		  if(session == null)
		    {	
		    	
		    	
		        response.sendRedirect("Login.html");
		    }
		  else{
		try {
			fareCalculation(request, response);
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}}
	}

	private void fareCalculation(HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			ClassNotFoundException, ServletException {

		FareDetailBean fareDetailBean = new FareDetailBean();
		FareDetail fareDetail = new FareDetail();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		fareDetailBean.setFromplace(request.getParameter("pp"));
		fareDetailBean.setToplace(request.getParameter("dp"));
		fareDetailBean.setType(request.getParameter("cs"));
		
		
		HttpSession session = request.getSession(false);
		
		  
		session.setAttribute("pickup",request.getParameter("pp")); 
		session.setAttribute("drop",request.getParameter("dp"));
		
		
		/*if(fareDetailBean.getFromplace().equals(fareDetailBean.getToplace())){
			out.print("<font color='#f9b535'>Pick up place is same as drop place!</font>");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("Drivedetails.jsp");
            requestDispatcher.include(request, response);
		}
		
		else{
*/
		ArrayList<FareDetailBean> arraylist = new ArrayList<FareDetailBean>();

		try {
			arraylist =  fareDetail.fareCalculation(fareDetailBean);
			request.setAttribute("arraylist", arraylist);
			RequestDispatcher rd = request.getRequestDispatcher("FareDetail.jsp");
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//}

	}
}
