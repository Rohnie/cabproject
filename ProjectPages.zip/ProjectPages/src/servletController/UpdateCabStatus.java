package servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import CustomerDetails.CustomerDetailsBean;
import UpdateStatus.UpdatePlace;
import UpdateStatus.UpdatePlaceBean;



public class UpdateCabStatus extends HttpServlet {
	final static Logger logger = Logger.getLogger(UpdateCabStatus.class);
	
	 public void doGet(HttpServletRequest request, HttpServletResponse response)  
             throws ServletException, IOException{
		 HttpSession session = request.getSession(false);
		  if(session == null)
		    {	
		    	
		    	
		        response.sendRedirect("Login.html");
		    }
		  else{
            try {
            	update(request, response);
            } catch (ClassNotFoundException e) {
                   
                   e.printStackTrace();
            } 
     }
	 }

     private void update(HttpServletRequest request,
                   HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
          
    	 UpdatePlaceBean updatePlaceBean = new UpdatePlaceBean();
    	 UpdatePlace updatePlace = new UpdatePlace();
            
            
            response.setContentType("text/html");  
         PrintWriter out = response.getWriter(); 
         
         HttpSession session = request.getSession(false);
       
        String mail_id = (String)session.getAttribute("mail");
         
         String currentPlace = request.getParameter("cl");
         
     // removed st from ui
    //     String status = request.getParameter("st");
         
         updatePlaceBean.setCurrentPlace(currentPlace);
      //   updatePlaceBean.setStatus(status);
         updatePlaceBean.setMail_id(mail_id);
         
         updatePlace.updateLocation(updatePlaceBean);  
         
         // change to status.equals(busy)
         // remove all related to status in UI
         
         if(updatePlace.checkStatus(mail_id)){
        	 CustomerDetailsBean customerDetailsBean = updatePlace.checkRequest(mail_id,updatePlaceBean);
        	 String name=customerDetailsBean.getName();
        	 logger.info("in checkstatus");
        //	System.out.println("in checkstatus");
        	 if(name.equals("")){
        		 logger.info("in name.equals");
        		// System.out.println("in name.equals");
        		 
        		 RequestDispatcher requestDispatcher = request.getRequestDispatcher("Cabstatus.jsp");
                 requestDispatcher.include(request, response);
        	 }
        	 else{
        		 logger.info("in userdetails");
        	//	 System.out.println("in userdetails");
        	 request.setAttribute("customerDetailsBean", customerDetailsBean);
             RequestDispatcher requestDispatcher = request.getRequestDispatcher("Userdetails.jsp");
             requestDispatcher.include(request, response);
        	 }
         }
         
         else{ 
        	 logger.info("in else checkstatus");
        	// System.out.println("in else checkstatus");
         RequestDispatcher requestDispatcher = request.getRequestDispatcher("Cabstatus.jsp");
         requestDispatcher.include(request, response);
         }
        
          }
}