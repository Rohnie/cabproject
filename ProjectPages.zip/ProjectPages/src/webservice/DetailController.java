package webservice;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



import Viewdetails.DetailBean;
import Viewdetails.DetailDao;




@RestController
@RequestMapping(value = "/details")
public class DetailController {

	
	 @RequestMapping(value = "/all" , method = RequestMethod.GET )
	  public ArrayList<DetailBean> getDetails() {
		 DetailDao detailDao = new DetailDao();
		
		ArrayList<DetailBean> list = new ArrayList<DetailBean>();  
		list=detailDao.getDetails();
		//System.out.println(list.size());
   	return list;
     }	 
	 
	 
}
