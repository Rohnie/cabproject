package Thankyou;



public class CheckService {
	public boolean check(String mail_id) throws ClassNotFoundException{
		boolean result=false;
		CheckServiceDao checkServiceDao = new CheckServiceDao();
		result=checkServiceDao.check(mail_id);
		return result;
	}
}
