package Thankyou;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DBConnection.ConnectionManager;

public class CheckServiceDao {
public boolean check(String mail_id){
		
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		boolean result=false;
		ResultSet resultset = null;
		String searchQuery = "SELECT STATUS from T_XBBNHDQ_MAP WHERE CUST_ID = ? ";
		
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mail_id);
			resultset = stmt.executeQuery();
			while (resultset.next()) {
			String status=resultset.getString(1);
			if(status.equals("serviced")){
				result=true;
			}
			else{
				result=false;
			}
			}
			
			 
        } catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return result;
	}
}
