package com.nxn.tra.api.dao;

import java.util.List;

import com.nxn.tra.api.model.Test;

public interface ITestDao {
	
	public List<Test> getAllTests() throws Exception;

	


}
