package com.nxn.tra.api.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.nxn.tra.api.dao.ITestDao;
import com.nxn.tra.api.model.Test;
import com.nxn.tra.api.rowmapper.TestRowMapper;

@Component
public class TestDaoImpl extends JdbcDaoSupport implements ITestDao {

	@Autowired
	public TestDaoImpl(DataSource datasource) {
		// TODO Auto-generated constructor stub
		setDataSource(datasource);
	}

	public List<Test> getAllTests() throws Exception {
		// TODO Auto-generated method stub
		List<Test> testList = null;

		testList = getJdbcTemplate().query("select * from T_XBBNHDQ_LOGIN_DET",
				new Object[] {}, new TestRowMapper());

		return testList;
	}

	
}
