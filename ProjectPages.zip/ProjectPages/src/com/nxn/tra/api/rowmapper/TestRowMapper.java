package com.nxn.tra.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nxn.tra.api.model.Test;

public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		
Test detailBean =new Test();
		
		detailBean.setFirstName(rs.getString(1));
		detailBean.setLastName(rs.getString(2));
		detailBean.setEmail(rs.getString(3));
		detailBean.setMobileNum(rs.getString(4));
		detailBean.setPassword(rs.getString(5));
		detailBean.setUser_type(rs.getString(6));
		return detailBean;
	}
	}


