package com.nxn.tra.api.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nxn.tra.api.daoimpl.TestDaoImpl;
import com.nxn.tra.api.model.Data;
import com.nxn.tra.api.model.ErrorDetails;
import com.nxn.tra.api.model.MetaData;
import com.nxn.tra.api.model.Response;
import com.nxn.tra.api.model.Test;


@RestController
public class TestController {
	
	
	@Autowired
	TestDaoImpl testDaoimpl;
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@Autowired
	ErrorDetails errorDetails;
	
	@RequestMapping(value="/tests", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
		
	public List<Test> getAllTestDetails()
	{
		
		List<Test> testList=new ArrayList<Test>();
		try {
			testList = testDaoimpl.getAllTests();
          System.out.println("Controller working");
			saveMetaData(true,"Tests loaded","12345");
			saveData(null, testList);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,errorDetails);
			//return response;
		}
		return testList;
	}
	

	
	private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
			data.setOutput(testObj);
		
	}
	
	
	
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	

}
