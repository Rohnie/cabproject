package project;

import java.util.*;

import FareCalculation.FareDetailBean;
import FareCalculation.FareDetailDao;
import Login.Login;
import Login.LoginBean;
import NearbyCab.NearbyCabBean;
import NearbyCab.NearbyCabDao;
import Signup.Signup;
import Signup.SignupBean;
public class Main {
	public static void main(String args[]) throws ClassNotFoundException{
		Scanner sc=new Scanner(System.in);
		//0.1 SIGNUP VALIDATE
		System.out.println("enter first name");
		String fname=sc.next();
		System.out.println("enter last name");
		String lname=sc.next();
		System.out.println("enter mail id");
		String mailid=sc.next();
		System.out.println("enter mobile number");
		String mobnum=sc.next();
		System.out.println("enter password");
		String password=sc.next();
		SignupBean signupbean=new SignupBean();
		signupbean.setFirstName(fname);
		signupbean.setLastName(lname);
		signupbean.setMobileNum(mobnum);
		signupbean.setEmail(mailid);
		signupbean.setPassword(password);
		Signup signup=new Signup();
		if(signup.validate(signupbean))
			System.out.println("signup success");
		else
			System.out.println("mail id already exists");
		

		//0.login validate
		System.out.println("enter mail id");
		String mail_id=sc.next();
		System.out.println("enter password");
		String pass_word=sc.next();
		LoginBean loginbean=new LoginBean();
		loginbean.setEmail(mailid);
		loginbean.setPassword(password);
		Login login=new Login();
		if(login.validate(loginbean))
			System.out.println("login success");
		else
			System.out.println("login failed");
		

		//1.to get fare detail
		FareDetailDao fareDetailDao = new FareDetailDao();
		
		String from="Alandur";
		String to="Adambakkam";
		
		/*List<FareDetailBean> fareList = fareDetailDao.fareCalculation(from, to);
		Iterator<FareDetailBean> itr = fareList.iterator();
		while(itr.hasNext()){
			FareDetailBean fareDetailBean = itr.next();
			System.out.println(fareDetailBean.getFromplace()+" "+fareDetailBean.getToplace()+" "+fareDetailBean.getTotdistance()+" "+fareDetailBean.getFare());
			}*/
		System.out.println();
		
		//2.to get nearby cabs
		NearbyCabDao nearbyCabDao = new NearbyCabDao();
		String[] currentPlace={"Adambakkam"};
		
		
		/*List<NearbyCabBean> nearbyCabList = nearbyCabDao.getCabDetails(currentPlace);
		Iterator<NearbyCabBean> itr1 = nearbyCabList.iterator();
		while(itr1.hasNext()){
			NearbyCabBean nearbyCabBean = itr1.next();
			System.out.println(nearbyCabBean.getCabnumber()+" "+nearbyCabBean.getCurrentPlace()+" "+nearbyCabBean.getStatus());
			}
		System.out.println();*/
		
		//3.to get cab details
		/*CabDetailDao cabDetailDao = new CabDetailDao();
		String cabno="123";
		
		
		List<CabDetailBean> cabDetailList = cabDetailDao.getCabDetails(cabno);
		Iterator<CabDetailBean> itr2  = cabDetailList.iterator();
		while(itr2.hasNext()){
			CabDetailBean cabDetailBean = itr2.next();
			System.out.println(cabDetailBean.getCabnumber()+" "+cabDetailBean.getName()+" "+cabDetailBean.getPhno());
			}*/
		System.out.println();
		
		//4.to cancel
		/*CabCancelDao cabCancelDao = new CabCancelDao();
		String cabNum="456";
		
		cabCancelDao.updateCabList(cabNum);*/
		
		//5.to update place and status
		/*UpdatePlaceDao updatePlaceDao = new UpdatePlaceDao();
		String cabNum1="234";
		String currentPlace1="Guindy";
		String status="busy";
		updatePlaceDao.updateCabList(cabNum1,currentPlace1,status);*/
	}

}
