package UpdateStatus;

public class UpdatePlaceBean {
private String currentPlace;
//private String status;
private String cabnum;
private String mail_id;
public String getMail_id() {
	return mail_id;
}
public void setMail_id(String mail_id) {
	this.mail_id = mail_id;
}
public String getCabnum() {
	return cabnum;
}
public void setCabnum(String cabnum) {
	this.cabnum = cabnum;
}
public String getCurrentPlace() {
	return currentPlace;
}
public void setCurrentPlace(String currentPlace) {
	this.currentPlace = currentPlace;
}
/*public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}*/
}
