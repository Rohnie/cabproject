package UpdateStatus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import CustomerDetails.CustomerDetailsBean;
import DBConnection.ConnectionManager;
import IUpdatePlace.iUpdate;
//import project.ConnectionManager;

public class UpdatePlaceDao implements iUpdate{
public void updateCabList(UpdatePlaceBean updatePlaceBean){
		
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet resultset = null;
		
		String searchQuery ="SELECT CAB_NUM from T_XBBNHDQ_CAB_DET WHERE PHNO = (SELECT MOBILE_NUMBER from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID = ?)";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, updatePlaceBean.getMail_id());
		
			resultset = stmt.executeQuery();
			
			
			while (resultset.next()) {
				updatePlaceBean.setCabnum(resultset.getString(1));
		    }
			
			 searchQuery = "UPDATE T_XBBNHDQ_CAB_DET SET CURRENT_PLACE=? WHERE CAB_NUM=?";
			 stmt = conn.prepareStatement(searchQuery);
			 stmt.setString(1, updatePlaceBean.getCurrentPlace());
			// stmt.setString(2, updatePlaceBean.getStatus());
			 stmt.setString(2, updatePlaceBean.getCabnum());
			
		     stmt.executeUpdate();	
		} 
		/*String searchQuery = "SELECT MOBILE_NUMBER from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, updatePlaceBean.getMail_id());
		
			resultset = stmt.executeQuery();
			
			
			while (resultset.next()) {
				
				String phno = resultset.getString(1);
				searchQuery = "SELECT CAB_NUM from T_XBBNHDQ_CAB_DET WHERE PHNO= ? ";
				stmt = conn.prepareStatement(searchQuery);
				stmt.setString(1, phno);
			
				ResultSet resultset1 = stmt.executeQuery();
				while (resultset1.next()) {
					
					updatePlaceBean.setCabnum(resultset1.getString(1));
					
				}
			}
			
			 searchQuery = "UPDATE T_XBBNHDQ_CAB_DET SET CURRENT_PLACE=? WHERE CAB_NUM=?";
			 stmt = conn.prepareStatement(searchQuery);
			 stmt.setString(1, updatePlaceBean.getCurrentPlace());
			// stmt.setString(2, updatePlaceBean.getStatus());
			 stmt.setString(2, updatePlaceBean.getCabnum());
			
		     stmt.executeUpdate();	
		}*/ catch (SQLException e) {
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		
	}

public CustomerDetailsBean checkRequest(String mail_id, UpdatePlaceBean updatePlaceBean){
	
	
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	ResultSet resultset = null;
	CustomerDetailsBean customerDetailsBean = new CustomerDetailsBean();
	
	
	String searchQuery = "SELECT * from T_XBBNHDQ_MAP WHERE DRIVER_ID= ? ";
	try {
		stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, mail_id);
	
		resultset = stmt.executeQuery();
		while (resultset.next()) {
			
		
			searchQuery = "SELECT * from T_XBBNHDQ_MAP WHERE DRIVER_ID= ? AND STATUS='requested' ";
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, mail_id);
	        ResultSet resultset1 = stmt.executeQuery();
			while (resultset1.next()) {
				 //inside check request 1
				customerDetailsBean.setCustomer_id(resultset1.getString(1));
				customerDetailsBean.setDriver_id(resultset1.getString(2));
				customerDetailsBean.setPick_up(resultset1.getString(3));
				customerDetailsBean.setDrop(resultset1.getString(4));
				customerDetailsBean.setMob_num(resultset1.getString(5));
				customerDetailsBean.setFare(resultset1.getInt(6));
				
				searchQuery = "SELECT FIRST_NAME, LAST_NAME from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
				stmt = conn.prepareStatement(searchQuery);
				stmt.setString(1, customerDetailsBean.getCustomer_id());
				ResultSet resultset2 = stmt.executeQuery();
				while (resultset2.next()) {
					 //inside check request 1
				customerDetailsBean.setName(resultset2.getString(1)+" "+resultset2.getString(2));
				}
				
			/*	
				searchQuery = "UPDATE T_XBBNHDQ_CAB_DET SET STATUS='busy' WHERE CAB_NUM=?";
				stmt = conn.prepareStatement(searchQuery);
				stmt.setString(1, updatePlaceBean.getCabnum());
				stmt.executeUpdate();*/
			}
		}
		
		 	
	} catch (SQLException e) {
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
	
	return customerDetailsBean;
}

public boolean checkStatus (String mail_id){
	
	
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	ResultSet resultset = null;
	boolean status=false;
	String searchQuery = "SELECT MOBILE_NUMBER from T_XBBNHDQ_LOGIN_DET WHERE EMAIL_ID= ? ";
	try {
		stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, mail_id);
	
		resultset = stmt.executeQuery();
		
		
		while (resultset.next()) {
			
			String phno = resultset.getString(1);
		//	System.out.println(phno);
			
			searchQuery = "SELECT STATUS from T_XBBNHDQ_CAB_DET WHERE PHNO= ? ";
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, phno);
			
			ResultSet resultset1 = stmt.executeQuery();
			while (resultset1.next()) {
				
				String st= resultset1.getString(1);
				System.out.println(st);
				if(st.equals("busy")){
				
					status=true;
				}
				else
					status=false;
			}
		}
		
		
	} catch (SQLException e) {
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
	return status;
	
}


	
}
