package UpdateStatus;

import CustomerDetails.CustomerDetailsBean;



public class UpdatePlace {
	public void updateLocation(UpdatePlaceBean updatePlaceBean) throws ClassNotFoundException{
		
		UpdatePlaceDao updatePlaceDao = new UpdatePlaceDao();
		updatePlaceDao.updateCabList(updatePlaceBean);
		
	}
	
public CustomerDetailsBean checkRequest(String mail_id, UpdatePlaceBean updatePlaceBean) throws ClassNotFoundException{
		
		UpdatePlaceDao updatePlaceDao = new UpdatePlaceDao();
		CustomerDetailsBean customerDetailsBean = updatePlaceDao.checkRequest(mail_id,updatePlaceBean);
		return customerDetailsBean;
	}

public boolean checkStatus(String mail_id) throws ClassNotFoundException{
	
	UpdatePlaceDao updatePlaceDao = new UpdatePlaceDao();
	boolean status = updatePlaceDao.checkStatus(mail_id);
	return status;
}
}
